﻿using System;

namespace FieldAgent.Core.DTOs
{
    public class TopAgentListItem
    {
        public string NameLastFirst { get; set; }
        public DateTime DateOfBirth { get; set; }
        public int CompletedMissionCount { get; set; }
    }
}
